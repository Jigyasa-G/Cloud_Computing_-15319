import boto3
import botocore
import requests
import time
import json
import configparser
import re
from dateutil.parser import parse


########################################
# Constants
########################################
with open('horizontal-scaling-config.json') as file:
    configuration = json.load(file)

LOAD_GENERATOR_AMI = configuration['load_generator_ami']
WEB_SERVICE_AMI = configuration['web_service_ami']
INSTANCE_TYPE = configuration['instance_type']

########################################
# Tags
########################################
tag_pairs = [
    ("Project", "vm-scaling"),
]
TAGS = [{'Key': k, 'Value': v} for k, v in tag_pairs]

TEST_NAME_REGEX = r'name=(.*log)'

########################################
# Utility functions
########################################


def create_instance(ami, sg_id, region_name = 'us-east-1'):
    """
    Given AMI, create and return an AWS EC2 instance object
    :param ami: AMI image name to launch the instance with
    :param sg_id: ID of the security group to be attached to instance
    :return: instance object
    """
    # Create an EC2 instance
    ec2 = boto3.resource('ec2', region_name = region_name)
    instance = ec2.create_instances(
        ImageId=ami,
        InstanceType='m5.large',
        SecurityGroupIds=[sg_id],
        MinCount=1,
        MaxCount=1,
        TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': TAGS
            }
        ]
    )[0]

    # Wait for the instance to enter the running state
    instance.wait_until_running()
    # Reload the instance attributes
    instance.reload()

    return instance


def initialize_test(lg_dns, first_web_service_dns):
    """
    Start the horizontal scaling test
    :param lg_dns: Load Generator DNS
    :param first_web_service_dns: Web service DNS
    :return: Log file name
    """

    add_ws_string = 'http://{}/test/horizontal?dns={}'.format(
        lg_dns, first_web_service_dns
    )
    print(f"got url of adding ws {add_ws_string}")
    print(f"\n got the new web service dns as {first_web_service_dns}")
    response = None
    while not response or response.status_code != 200:
        try:
            response = requests.get(add_ws_string)
        except requests.exceptions.ConnectionError:
            time.sleep(1)
            pass 
    print("added the dns to test")
    # TODO: return log File name
    match = re.search(r"log\?name=(test\.\d+\.log)", response.text)
    if match:
        log_file_name = match.group(1)
        print("Extracted log file name: " + log_file_name)
        return log_file_name
    else:
        raise ValueError("Could not extract log file name from response.")
    
    # log_file_name = response.text.strip()
    # print("got the log file name " + log_file_name)
    # return log_file_name


def print_section(msg):
    """
    Print a section separator including given message
    :param msg: message
    :return: None
    """
    print(('#' * 40) + '\n# ' + msg + '\n' + ('#' * 40))


def get_test_id(response):
    """
    Extracts the test id from the server response.
    :param response: the server response.
    :return: the test name (log file name).
    """
    response_text = response.text

    regexpr = re.compile(TEST_NAME_REGEX)

    return regexpr.findall(response_text)[0]


def is_test_complete(lg_dns, log_name):
    """
    Check if the horizontal scaling test has finished
    :param lg_dns: load generator DNS
    :param log_name: name of the log file
    :return: True if Horizontal Scaling test is complete and False otherwise.
    """

    log_string = 'http://{}/log?name={}'.format(lg_dns, log_name)

    # creates a log file for submission and monitoring
    f = open(log_name + ".log", "w")
    log_text = requests.get(log_string).text
    f.write(log_text)
    f.close()

    return '[Test finished]' in log_text


def add_web_service_instance(lg_dns, sg2_id, log_name, created_instance_ids):
    """
    Launch a new WS (Web Server) instance and add to the test
    :param lg_dns: load generator DNS
    :param sg2_id: id of WS security group
    :param log_name: name of the log file
    """
    ins = create_instance(WEB_SERVICE_AMI, sg2_id)
    created_instance_ids.append(ins.instance_id)
    print("New WS launched. id={}, dns={}".format(
        ins.instance_id,
        ins.public_dns_name)
    )
    add_req = 'http://{}/test/horizontal/add?dns={}'.format(
        lg_dns,
        ins.public_dns_name
    )
    while True:
        if requests.get(add_req).status_code == 200:
            print("New WS submitted to LG.")
            break
        elif is_test_complete(lg_dns, log_name):
            print("New WS not submitted because test already completed.")
            break


def get_rps(lg_dns, log_name):
    """
    Return the current RPS as a floating point number
    :param lg_dns: LG DNS
    :param log_name: name of log file
    :return: latest RPS value
    """

    log_string = 'http://{}/log?name={}'.format(lg_dns, log_name)
    config = configparser.ConfigParser(strict=False)
    config.read_string(requests.get(log_string).text)
    sections = config.sections()
    sections.reverse()
    rps = 0
    for sec in sections:
        if 'Current rps=' in sec:
            rps = float(sec[len('Current rps='):])
            break
    return rps


def get_test_start_time(lg_dns, log_name):
    """
    Return the test start time in UTC
    :param lg_dns: LG DNS
    :param log_name: name of log file
    :return: datetime object of the start time in UTC
    """
    log_string = 'http://{}/log?name={}'.format(lg_dns, log_name)
    start_time = None
    # while start_time is None:
    #     config = configparser.ConfigParser(strict=False)
    #     config.read_string(requests.get(log_string).text)
    #     # By default, options names in a section are converted
    #     # to lower case by configparser
    #     start_time = dict(config.items('Test')).get('starttime', None)
    # return parse(start_time)

    while start_time is None:
        try:
            response = requests.get(log_string)
            response.raise_for_status()  # Raise an error for HTTP issues
            log_text = response.text
            config = configparser.ConfigParser(strict=False)
            config.read_string(log_text)
            
            # Check if [Test] section exists
            if 'Test' in config:
                start_time_str = dict(config.items('Test')).get('starttime', None)
                if start_time_str:
                    start_time = parse(start_time_str)
                else:
                    print("Start time not found in [Test] section. Retrying...")
            else:
                print("No [Test] section in log. Retrying...")
        except Exception as e:
            print(f"Error retrieving test start time: {e}. Retrying...")
        
        time.sleep(1) 
        return start_time

### Creating Security Groups
def create_security_group(group_name, description, region_name='us-east-1'):
    ec2 = boto3.client('ec2', region_name = region_name)
    try:
        response = ec2.describe_security_groups(
            Filters=[
                {'Name': 'group-name', 'Values': [group_name]}
            ]
        )
        if len(response['SecurityGroups']) > 0:
            print(f"Security group '{group_name}' already exists.")
            return response['SecurityGroups'][0]['GroupId']
    except botocore.exceptions.ClientError as e:
        print(f"Error checking for existing security group: {e}")


    response = ec2.create_security_group(GroupName=group_name, Description=description)
    sg_id = response['GroupId']
    print(f"Created security group: {group_name}, ID: {sg_id}")
    
    ec2.authorize_security_group_ingress(
        GroupId=sg_id,
        IpPermissions=[
            {
                'IpProtocol': 'tcp',
                'FromPort': 80,
                'ToPort': 80,
                'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
            }
        ]
    )
    
    return sg_id

##Terminate Instances
def terminate_instances(instance_ids):
    """
    Terminate the given instances
    :param instance_ids: List of instance IDs to terminate
    """
    ec2 = boto3.client('ec2')
    response = ec2.terminate_instances(InstanceIds=instance_ids)
    print(f"Terminating instances: {instance_ids}")
    return response

########################################
# Main routine
########################################
def main():
    # BIG PICTURE TODO: Provision resources to achieve horizontal scalability
    #   - Create security groups for Load Generator and Web Service
    #   - Provision a Load Generator instance
    #   - Provision a Web Service instance
    #   - Register Web Service DNS with Load Generator
    #   - Add Web Service instances to Load Generator
    #   - Terminate resources

    # A list of all instance IDs of instances created
    created_instance_ids = []

    print_section('1 - create two security groups')
    sg_permissions = [
        {'IpProtocol': 'tcp',
         'FromPort': 80,
         'ToPort': 80,
         'IpRanges': [{'CidrIp': '0.0.0.0/0'}],
         'Ipv6Ranges': [{'CidrIpv6': '::/0'}],
         }
    ]

    # Create two separate security groups and obtain the group ids
    sg1_id = create_security_group('load-generator-sg', 'Security group for Load Generator', region_name='us-east-1')  # Security group for Load Generator instances

    sg2_id = create_security_group('web-service-sg', 'Security group for Web Service', region_name='us-east-1')  # Security group for Web Service instances

    print_section('2 - create LG')

    # Create Load Generator instance and obtain ID and DNS
    lg = create_instance(LOAD_GENERATOR_AMI, sg1_id, region_name='us-east-1')
    lg_id = lg.instance_id
    lg_dns = lg.public_dns_name
    print("Load Generator running: id={} dns={}".format(lg_id, lg_dns))

    # Create First Web Service Instance and obtain the DNS
    web_service_dns = create_instance(WEB_SERVICE_AMI, sg2_id, region_name='us-east-1')
    ws_id = web_service_dns.instance_id
    ws_dns = web_service_dns.public_dns_name
    created_instance_ids.append(ws_id)
    print("Web Service running: id={} dns={}".format(ws_id, ws_dns))

    print_section('3. Submit the first WS instance DNS to LG, starting test.')
    log_name = initialize_test(lg_dns, ws_dns)
    last_launch_time = get_test_start_time(lg_dns, log_name).timestamp()
    print(f"launch time start {last_launch_time}")
    while not is_test_complete(lg_dns, log_name):
        # Check RPS and last launch time
        current_rps = get_rps(lg_dns, log_name)
        print(f"the current rps is {current_rps}")
        # Add New Web Service Instance if Required
        if current_rps < 50 and time.time() - last_launch_time > 100:
            print(f"got status to add new instance ")
            add_web_service_instance(lg_dns, sg2_id, log_name, created_instance_ids)
            last_launch_time = time.time()
        time.sleep(1)

    print_section('End Test')

    # Terminate Resources
    terminate_instances(created_instance_ids)

if __name__ == '__main__':
    main()
