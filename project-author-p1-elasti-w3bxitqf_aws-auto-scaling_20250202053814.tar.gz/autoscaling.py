import boto3
import botocore
import requests
import time
import json
import re
import base64
from datetime import datetime, timedelta



########################################
# Constants
########################################
with open('auto-scaling-config.json') as file:
    configuration = json.load(file)

LOAD_GENERATOR_AMI = configuration['load_generator_ami']
WEB_SERVICE_AMI = configuration['web_service_ami']
INSTANCE_TYPE = configuration['instance_type']
ASG_MIN_SIZE = configuration['asg_min_size']
ASG_MAX_SIZE = configuration['asg_max_size']
HEALTH_CHECK_GRACE_PERIOD = configuration['health_check_grace_period']
COOL_DOWN_PERIOD_SCALE_IN = configuration['cool_down_period_scale_in']
COOL_DOWN_PERIOD_SCALE_OUT = configuration['cool_down_period_scale_out']
SCALE_OUT_ADJUSTMENT = configuration['scale_out_adjustment']
SCALE_IN_ADJUSTMENT = configuration['scale_in_adjustment']
ASG_DEFAULT_COOL_DOWN_PERIOD = configuration['asg_default_cool_down_period']
ALARM_PERIOD = configuration['alarm_period']
CPU_LOWER_THRESHOLD = configuration['cpu_lower_threshold']
CPU_UPPER_THRESHOLD = configuration['cpu_upper_threshold']
ALARM_EVALUATION_PERIODS_SCALE_OUT = configuration['alarm_evaluation_periods_scale_out']
ALARM_EVALUATION_PERIODS_SCALE_IN = configuration['alarm_evaluation_periods_scale_in']
AUTO_SCALING_TARGET_GROUP = configuration['auto_scaling_target_group']
LOAD_BALANCER_NAME = configuration['load_balancer_name']
LAUNCH_TEMPLATE_NAME = configuration['launch_template_name']
AUTO_SCALING_GROUP_NAME = configuration['auto_scaling_group_name']


########################################
# Tags
########################################
tag_pairs = [
    ("Project", "vm-scaling"),
]
TAGS = [{'Key': k, 'Value': v} for k, v in tag_pairs]

TEST_NAME_REGEX = r'name=(.*log)'

########################################
# Utility functions
########################################


##Security Group
def create_security_group(group_name, description, vpc_id, region_name='us-east-1'):
    ec2 = boto3.client('ec2', region_name=region_name)

    try:
        response = ec2.describe_security_groups(
            Filters=[{'Name': 'group-name', 'Values': [group_name]}]
        )
        if response['SecurityGroups']:
            sg_id = response['SecurityGroups'][0]['GroupId']
            print(f"Security Group '{group_name}' already exists: id={sg_id}")
            return sg_id
    except botocore.exceptions.ClientError as e:
        print(f"Error fetching security groups: {e}")

    try:
        response = ec2.create_security_group(
            GroupName=group_name,
            Description=description,
            VpcId=vpc_id  
        )
        sg_id = response['GroupId']
        print(f"Created Security Group '{group_name}' in VPC '{vpc_id}': id={sg_id}")

        # Allow inbound traffic on port 80
        ec2.authorize_security_group_ingress(
            GroupId=sg_id,
            IpPermissions=[{
                'IpProtocol': 'tcp',
                'FromPort': 80,
                'ToPort': 80,
                'IpRanges': [{'CidrIp': '0.0.0.0/0'}],
                'Ipv6Ranges': [{'CidrIpv6': '::/0'}],
            }]
        )

        ec2.create_tags(
            Resources=[sg_id],
            Tags=TAGS
        )

        return sg_id
    except botocore.exceptions.ClientError as e:
        print(f"Failed to create security group {group_name}: {e}")
        return None


def create_instance(ami, sg_id, region_name='us-east-1'):
    """
    Given AMI, create and return an AWS EC2 instance object
    :param ami: AMI image name to launch the instance with
    :param sg_id: ID of the security group to be attached to instance
    :return: instance object
    """

    # TODO: Create an EC2 instance
    ec2 = boto3.resource('ec2', region_name=region_name)
    instance = ec2.create_instances(
        ImageId=ami,
        InstanceType=INSTANCE_TYPE,
        SecurityGroupIds=[sg_id],
        MinCount=1,
        MaxCount=1,
        TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': TAGS
            }
        ]
    )[0]

    instance.wait_until_running()
    instance.reload()
    print("Instance created: id={} dns={}".format(instance.id, instance.public_dns_name))

    return instance

def create_launch_template(ami, sg_id, region_name='us-east-1'):
    """
    Create a Launch Template if it does not exist, otherwise return the existing one.
    """
    ec2 = boto3.client('ec2', region_name=region_name)
    lt_name = LAUNCH_TEMPLATE_NAME
    print(f"thsi si security group id {sg_id}")
    try:
        # Check if Launch Template already exists
        response = ec2.describe_launch_templates(
            Filters=[{'Name': 'launch-template-name', 'Values': [lt_name]}]
        )
        if response['LaunchTemplates']:
            lt_id = response['LaunchTemplates'][0]['LaunchTemplateId']
            print(f"Launch Template '{lt_name}' already exists: id={lt_id}")
            return lt_id
    except botocore.exceptions.ClientError as e:
        print(f"Error checking for existing Launch Template: {e}")

    # If no existing launch template, create a new one
    user_data_script = """#!/bin/bash
    sudo apt-get update
    sudo apt-get install -y apache2
    sudo systemctl start apache2
    sudo systemctl enable apache2
    echo "<html><body><h1>Web Server is running</h1></body></html>" > /var/www/html/index.html
    """

    try:
        response = ec2.create_launch_template(
            LaunchTemplateName=lt_name,
            LaunchTemplateData={
                'ImageId': ami,
                'InstanceType': INSTANCE_TYPE,
                'SecurityGroupIds': [sg_id],  
                'Monitoring': {'Enabled': True},
                'UserData': base64.b64encode(user_data_script.encode('utf-8')).decode('utf-8'),
                'TagSpecifications': [{'ResourceType': 'instance', 'Tags': TAGS}]
            }
        )
        lt_id = response['LaunchTemplate']['LaunchTemplateId']
        print(f"Created new Launch Template '{lt_name}': id={lt_id}")
        return lt_id
    except botocore.exceptions.ClientError as e:
        print(f"Failed to create Launch Template '{lt_name}': {e}")
        return None


def get_default_vpc(region_name='us-east-1'):
    """
    Automatically fetch the default VPC ID for the given region.
    If no default VPC is found, return the first available VPC.
    """
    ec2 = boto3.client('ec2', region_name=region_name)
    response = ec2.describe_vpcs()
    
    # Find the default VPC
    for vpc in response['Vpcs']:
        if vpc.get('IsDefault', False):
            print(f"Using default VPC: {vpc['VpcId']}")
            return vpc['VpcId']
    
    # If no default VPC, use the first available one
    if response['Vpcs']:
        print(f"No default VPC found. Using first available VPC: {response['Vpcs'][0]['VpcId']}")
        return response['Vpcs'][0]['VpcId']
    
    print("No VPC found in this region.")
    return None

def get_vpc_subnets(vpc_id, region_name='us-east-1', public_only=True):
    """
    Fetches subnet IDs for a given VPC.
    If public_only is True, returns only subnets associated with a route table having an Internet Gateway.
    """
    ec2 = boto3.client('ec2', region_name=region_name)
    
    # Get all subnets in the VPC given
    response = ec2.describe_subnets(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
    subnets = [subnet['SubnetId'] for subnet in response['Subnets']]
    
    if not subnets:
        print("No subnets found for the given VPC.")
        return []
    
    # Return all subnets if public filtering is not needed
    if not public_only:
        return subnets  
    
    # Filter for public subnets associated with a route table 
    public_subnets = []
    route_tables = ec2.describe_route_tables()
    
    for rt in route_tables['RouteTables']:
        for route in rt.get('Routes', []):
            if route.get('GatewayId', '').startswith('igw-'):  
                for association in rt.get('Associations', []):
                    if 'SubnetId' in association and association['SubnetId'] in subnets:
                        public_subnets.append(association['SubnetId'])
    
    if not public_subnets:
        print("No public subnets found, using all available subnets.")
        return subnets  
    
    print(f"Public subnets found: {public_subnets}")
    return public_subnets


def create_target_group(vpc_id, region_name='us-east-1'):
    elbv2 = boto3.client('elbv2', region_name=region_name)
    response = elbv2.create_target_group(
        Name=AUTO_SCALING_TARGET_GROUP,
        Protocol='HTTP',
        Port=80,
        VpcId=vpc_id,
        HealthCheckProtocol='HTTP',
        HealthCheckPort='80',
        HealthCheckPath='/',
        TargetType='instance'
    )
    tg_arn = response['TargetGroups'][0]['TargetGroupArn']
    print(f"Target Group created: arn={tg_arn}")

    elbv2.add_tags(
        ResourceArns=[tg_arn],
        Tags=TAGS
    )
    print(f"Tagged Target Group with {TAGS}")

    return tg_arn

def create_load_balancer(subnets, sg_id, region_name='us-east-1'):
    elbv2 = boto3.client('elbv2', region_name=region_name)
    # If Load Balancer already exists
    response = elbv2.describe_load_balancers()
    for lb in response['LoadBalancers']:
        if lb['LoadBalancerName'] == LOAD_BALANCER_NAME:
            print(f"Load Balancer already exists: ARN={lb['LoadBalancerArn']}, DNS={lb['DNSName']}")
            return lb['LoadBalancerArn'], lb['DNSName']

    # If not found, create a new Load Balancer
    response = elbv2.create_load_balancer(
        Name=LOAD_BALANCER_NAME,
        Subnets=subnets,
        SecurityGroups=[sg_id],
        Scheme='internet-facing',
        Type='application',
        IpAddressType='ipv4',
        Tags=TAGS
    )
    
    lb_arn = response['LoadBalancers'][0]['LoadBalancerArn']
    lb_dns = response['LoadBalancers'][0]['DNSName']
    print(f"Created new Load Balancer: ARN={lb_arn}, DNS={lb_dns}")
    return lb_arn, lb_dns


def associate_target_group(lb_arn, tg_arn, region_name='us-east-1'):
    elbv2 = boto3.client('elbv2', region_name=region_name)
    response = elbv2.create_listener(
        LoadBalancerArn=lb_arn,
        Protocol='HTTP',
        Port=80,
        DefaultActions=[
            {
                'Type': 'forward',
                'TargetGroupArn': tg_arn
            }
        ]
    )
    return response['Listeners'][0]['ListenerArn']

def create_auto_scaling_group(lt_id, tg_arn, region_name='us-east-1'):
    autoscaling = boto3.client('autoscaling', region_name=region_name)
    
    vpc_id = get_default_vpc(region_name=region_name)  
    print(f"Using VPC: {vpc_id}")
    subnets = get_vpc_subnets(vpc_id, region_name=region_name) 
    vpc_zone_identifier = ",".join(subnets)
    print(f"Using subnets: {vpc_zone_identifier}")

    response = autoscaling.create_auto_scaling_group(  
        AutoScalingGroupName=AUTO_SCALING_GROUP_NAME,
        LaunchTemplate={
            'LaunchTemplateId': lt_id,
            'Version': '$Latest'
        },
        MinSize=ASG_MIN_SIZE,
        MaxSize=ASG_MAX_SIZE,
        DesiredCapacity=ASG_MIN_SIZE, 
        TargetGroupARNs=[tg_arn],
        HealthCheckType='EC2',
        HealthCheckGracePeriod=HEALTH_CHECK_GRACE_PERIOD,
        VPCZoneIdentifier=vpc_zone_identifier,
        DefaultCooldown = ASG_DEFAULT_COOL_DOWN_PERIOD,
        Tags=[  
        {
                'ResourceId': AUTO_SCALING_GROUP_NAME,
                'ResourceType': 'auto-scaling-group',
                'Key': 'Project',
                'Value': 'vm-scaling',
                'PropagateAtLaunch': True
            }
        ]  
    )

    return response

def create_scaling_policy(asg_name, policy_name, adjustment_type, scaling_adjustment, scale_in, region_name='us-east-1'):
    autoscaling = boto3.client('autoscaling', region_name=region_name)
    response = autoscaling.put_scaling_policy(
        AutoScalingGroupName=asg_name,
        PolicyName=policy_name,
        PolicyType='SimpleScaling',
        AdjustmentType=adjustment_type,
        ScalingAdjustment=scaling_adjustment,
        Cooldown=COOL_DOWN_PERIOD_SCALE_IN if scale_in else COOL_DOWN_PERIOD_SCALE_OUT 
    )
    return response['PolicyARN']

def initialize_test(load_generator_dns, first_web_service_dns):
    """
    Start the auto scaling test
    :param lg_dns: Load Generator DNS
    :param first_web_service_dns: Web service DNS
    :return: Log file name
    """

    add_ws_string = 'http://{}/autoscaling?dns={}'.format(
        load_generator_dns, first_web_service_dns
    )
    response = None
    while not response or response.status_code != 200:
        try:
            response = requests.get(add_ws_string)
            if response.status_code == 200:
                print("Auto scaling test started successfully.")
        except requests.exceptions.ConnectionError:
            time.sleep(1)
            pass 

    # TODO: return log File name
    return get_test_id(response)

def create_cloudwatch_alarm(alarm_name, metric_name, namespace, statistic, period, evaluation_periods, threshold, comparison_operator, alarm_actions, dimensions, region_name='us-east-1'):
    cloudwatch = boto3.client('cloudwatch', region_name=region_name)
    response = cloudwatch.put_metric_alarm(
        AlarmName=alarm_name,
        MetricName=metric_name,
        Namespace=namespace,
        Statistic=statistic,
        Period=period,
        EvaluationPeriods=evaluation_periods,
        Threshold=threshold,
        ComparisonOperator=comparison_operator,
        AlarmActions=alarm_actions,
        Dimensions=dimensions
    )
    return response

def monitor_metrics():
    cloudwatch = boto3.client('cloudwatch', region_name='us-east-1')
    metrics = [
        'RequestCount',
        'HTTPCode_Target_2XX_Count',
        'HTTPCode_Target_4XX_Count',
        'TargetResponseTime',
        'CPUUtilization'
    ]
    for metric in metrics:
        response = cloudwatch.get_metric_statistics(
            Namespace='AWS/ELB',
            MetricName=metric,
            Dimensions=[
                {
                    'Name': 'LoadBalancerName',
                    'Value': LOAD_BALANCER_NAME
                }
            ],
            StartTime=datetime.utcnow() - timedelta(minutes=10),
            EndTime=datetime.utcnow(),
            Period=60,
            Statistics=['Average']
        )
        print(f"Metric: {metric}")
        for datapoint in response['Datapoints']:
            print(datapoint)

def adjust_policies(scale_out_policy_arn, scale_in_policy_arn):
    create_cloudwatch_alarm(
        alarm_name='scale-out-alarm',
        metric_name='CPUUtilization',
        namespace='AWS/EC2',
        statistic='Average',
        period=ALARM_PERIOD,
        evaluation_periods=ALARM_EVALUATION_PERIODS_SCALE_OUT,
        threshold=CPU_UPPER_THRESHOLD,
        comparison_operator='GreaterThanThreshold',
        alarm_actions=[scale_out_policy_arn],
        dimensions=[{'Name': 'AutoScalingGroupName', 'Value': AUTO_SCALING_GROUP_NAME}],
        region_name='us-east-1'
    )

    create_cloudwatch_alarm(
        alarm_name='scale-in-alarm',
        metric_name='CPUUtilization',
        namespace='AWS/EC2',
        statistic='Average',
        period=ALARM_PERIOD,
        evaluation_periods=ALARM_EVALUATION_PERIODS_SCALE_IN,
        threshold=CPU_LOWER_THRESHOLD,
        comparison_operator='LessThanThreshold',
        alarm_actions=[scale_in_policy_arn],
        dimensions=[{'Name': 'AutoScalingGroupName', 'Value': AUTO_SCALING_GROUP_NAME}],
        region_name='us-east-1'
    )

    print("Adjusted scaling policies.")



def initialize_warmup(load_generator_dns, load_balancer_dns):
    """
    Start the warmup test
    :param lg_dns: Load Generator DNS
    :param load_balancer_dns: Load Balancer DNS
    :return: Log file name
    """

    add_ws_string = 'http://{}/warmup?dns={}'.format(
        load_generator_dns, load_balancer_dns
    )
    response = None
    while not response or response.status_code != 200:
        try:
            response = requests.get(add_ws_string)
            if response.status_code == 200:
                print("Warmup test started successfully.")
        except requests.exceptions.ConnectionError:
            time.sleep(1)
            pass  

    # TODO: return log File name
    return get_test_id(response)


def get_test_id(response):
    """
    Extracts the test id from the server response.
    :param response: the server response.
    :return: the test name (log file name).
    """
    response_text = response.text

    regexpr = re.compile(TEST_NAME_REGEX)

    return regexpr.findall(response_text)[0]


def destroy_resources():
    """
    Delete all resources created for this task

    We must destroy the following resources:
    Load Generator, Auto Scaling Group, Launch Template, Load Balancer, Security Group.
    Note that one resource may depend on another, and if resource A depends on resource B, we must delete resource B before we can delete resource A.
    Below are all the resource dependencies that we need to consider in order to decide the correct ordering of resource deletion.

    - Cannot delete Launch Template before deleting the Auto Scaling Group
    - Cannot delete a Security group before deleting the Load Generator and the Auto Scaling Groups
    - Must wait for the instances in the target group to be terminated before deleting the security groups

    :param msg: message
    :return: None
    """
    # TODO: implement this method
    region_name = 'us-east-1'
    autoscaling = boto3.client('autoscaling', region_name=region_name)
    ec2 = boto3.client('ec2', region_name=region_name)
    elbv2 = boto3.client('elbv2', region_name=region_name)

    # Deletion of Auto Scaling Group
    try:
        print("Deleting Auto Scaling Group...")
        autoscaling.update_auto_scaling_group(
            AutoScalingGroupName=AUTO_SCALING_GROUP_NAME,
            MinSize=0,
            MaxSize=0,
            DesiredCapacity=0
        )
        autoscaling.delete_auto_scaling_group(
            AutoScalingGroupName=AUTO_SCALING_GROUP_NAME,
            ForceDelete=True
        )
        print("Waiting for Auto Scaling Group to be deleted...")
        while True:
            response = autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[AUTO_SCALING_GROUP_NAME])
            if not response['AutoScalingGroups']:
                print("Auto Scaling Group deleted.")
                break
            time.sleep(10)
    except botocore.exceptions.ClientError as e:
        print(f"Auto Scaling Group deletion error: {e}")

    # Deletion of Launch Template
    try:
        print("Deleting Launch Template...")
        response = ec2.describe_launch_templates(Filters=[{'Name': 'launch-template-name', 'Values': [LAUNCH_TEMPLATE_NAME]}])
        if response['LaunchTemplates']:
            lt_id = response['LaunchTemplates'][0]['LaunchTemplateId']
            ec2.delete_launch_template(LaunchTemplateId=lt_id)
            print("Launch Template deleted.")
    except botocore.exceptions.ClientError as e:
        print(f"Launch Template deletion error: {e}")

    # Deletion of Load Balancer
    try:
        print("Deleting Load Balancer...")
        response = elbv2.describe_load_balancers(Names=[LOAD_BALANCER_NAME])
        if response['LoadBalancers']:
            lb_arn = response['LoadBalancers'][0]['LoadBalancerArn']
            elbv2.delete_load_balancer(LoadBalancerArn=lb_arn)
            print("Waiting for Load Balancer to be deleted...")
            waiter = elbv2.get_waiter('load_balancers_deleted')
            waiter.wait(LoadBalancerArns=[lb_arn])
            print("Load Balancer deleted.")
    except botocore.exceptions.ClientError as e:
        print(f"Load Balancer deletion error: {e}")

    # Deletion of EC2 Instances
    try:
        print("Terminating EC2 Instances...")
        instances = ec2.describe_instances(
            Filters=[
                {'Name': 'tag:Project', 'Values': ['vm-scaling']}
            ]
        )
        instance_ids = [i['InstanceId'] for r in instances['Reservations'] for i in r['Instances']]
        if instance_ids:
            ec2.terminate_instances(InstanceIds=instance_ids)
            print("Waiting for instances to terminate...")
            waiter = ec2.get_waiter('instance_terminated')
            waiter.wait(InstanceIds=instance_ids)
            print("Instances terminated.")
    except botocore.exceptions.ClientError as e:
        print(f"EC2 instance termination error: {e}")

    # Deletion of Target Group
    try:
        print("Deleting Target Group...")
        response = elbv2.describe_target_groups(Names=[AUTO_SCALING_TARGET_GROUP])
        if response['TargetGroups']:
            tg_arn = response['TargetGroups'][0]['TargetGroupArn']
            elbv2.delete_target_group(TargetGroupArn=tg_arn)
            print("Target Group deleted.")
    except botocore.exceptions.ClientError as e:
        print(f"Target Group deletion error: {e}")


    # Deletion of Security Groups
    try:
        print("Deleting Security Groups...")
        sg_names = ['load-generator-sg', 'asg-elb-sg']
        for sg_name in sg_names:
            response = ec2.describe_security_groups(Filters=[{'Name': 'group-name', 'Values': [sg_name]}])
            if response['SecurityGroups']:
                sg_id = response['SecurityGroups'][0]['GroupId']
                ec2.delete_security_group(GroupId=sg_id)
                print(f"Security Group '{sg_name}' deleted.")
    except botocore.exceptions.ClientError as e:
        print(f"Security Group deletion error: {e}")


def delete_auto_scaling_group(asg_name, region_name='us-east-1', timeout=300):
    autoscaling = boto3.client('autoscaling', region_name=region_name)

    try:
        # Check if ASG exists before deleting
        response = autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
        if not response['AutoScalingGroups']:
            print(f"Auto Scaling Group '{asg_name}' does not exist. Skipping deletion.")
            return

        # Delete ASG
        else:
            print(f"Deleting Auto Scaling Group: {asg_name}")
            autoscaling.delete_auto_scaling_group(AutoScalingGroupName=asg_name, ForceDelete=True)
            
            # Wait for deletion with a timeout (default: 5 minutes)
            start_time = time.time()
            while time.time() - start_time < timeout:
                response = autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
                if not response['AutoScalingGroups']:
                    print(f"Auto Scaling Group '{asg_name}' deleted successfully.")
                    return
                print("Waiting for ASG deletion...")
                time.sleep(10)  # Wait 10 seconds before next check

        print(f"Timeout reached: Auto Scaling Group '{asg_name}' still exists. Exiting.")
    
    except botocore.exceptions.ClientError as e:
        print(f"Error deleting ASG: {e}")



def print_section(msg):
    """
    Print a section separator including given message
    :param msg: message
    :return: None
    """
    print(('#' * 40) + '\n# ' + msg + '\n' + ('#' * 40))


def is_test_complete(load_generator_dns, log_name):
    """
    Check if auto scaling test is complete
    :param load_generator_dns: lg dns
    :param log_name: log file name
    :return: True if Auto Scaling test is complete and False otherwise.
    """
    log_string = 'http://{}/log?name={}'.format(load_generator_dns, log_name)

    # creates a log file for submission and monitoring
    f = open(log_name + ".log", "w")
    log_text = requests.get(log_string).text
    f.write(log_text)
    f.close()

    return '[Test finished]' in log_text


########################################
# Main routine
########################################
def main():
    # BIG PICTURE TODO: Programmatically provision autoscaling resources
    #   - Create security groups for Load Generator and ASG, ELB
    #   - Provision a Load Generator
    #   - Generate a Launch Template
    #   - Create a Target Group
    #   - Provision a Load Balancer
    #   - Associate Target Group with Load Balancer
    #   - Create an Autoscaling Group
    #   - Initialize Warmup Test
    #   - Initialize Autoscaling Test
    #   - Terminate Resources

    print_section('1 - create two security groups')

    # Load Generator Security Group: Allows traffic on port 80
    lg_permissions = [
        {'IpProtocol': 'tcp',
         'FromPort': 80,
         'ToPort': 80,
         'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
        }
    ]

    # ASG & ELB Security Group: Allows traffic from the Load Balancer and to instances
    asg_elb_permissions = [
        {'IpProtocol': 'tcp',
         'FromPort': 80,
         'ToPort': 80,
         'SourceSecurityGroupName': 'asg-elb-sg'
        }
    ]

    vpc_id = get_default_vpc(region_name='us-east-1')
    print(f"Using VPC: {vpc_id}")

    # TODO: create two separate security groups and obtain the group ids
    sg1_id = create_security_group('load-generator-sg', 'Security group for Load Generator', vpc_id, region_name='us-east-1')
    sg2_id = create_security_group('asg-elb-sg', 'Security group for ASG and ELB', vpc_id, region_name='us-east-1')
    
    print_section('2 - create LG')

    # TODO: Create Load Generator instance and obtain ID and DNS
    lg = create_instance(LOAD_GENERATOR_AMI, sg1_id, region_name='us-east-1')
    lg_id = lg.instance_id
    lg_dns = lg.public_dns_name
    print("Load Generator running: id={} dns={}".format(lg_id, lg_dns))

    print_section('3. Create LT (Launch Template)')
    # TODO: create launch Template
    lt_id = create_launch_template(WEB_SERVICE_AMI, sg2_id, region_name='us-east-1')
    print("Launch Template created: id={}".format(lt_id))

    print_section('4. Create TG (Target Group)')
    # TODO: create Target Group
    vpc_id = get_default_vpc(region_name='us-east-1')
    # Replace with VPC ID
    tg_arn = create_target_group(vpc_id, region_name='us-east-1')
    print("Target Group created: arn={}".format(tg_arn))


    print_section('5. Create ELB (Elastic/Application Load Balancer)')

    # TODO create Load Balancer
    # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/elbv2.html
    
    #TODO:Replace subnet IDs
    vpc_id = get_default_vpc(region_name='us-east-1')  
    subnets = get_vpc_subnets(vpc_id, region_name='us-east-1')  
    lb_arn, lb_dns = create_load_balancer(subnets, sg2_id, region_name='us-east-1')
    print("Load Balancer started. ARN={}, DNS={}".format(lb_arn, lb_dns))

    print_section('6. Associate ELB with target group')
    # TODO Associate ELB with target group
    listener_arn = associate_target_group(lb_arn, tg_arn, region_name='us-east-1')
    print("Listener created: arn={}".format(listener_arn))

    print_section('7. Create ASG (Auto Scaling Group)')
    # TODO create Autoscaling group
    asg_name = AUTO_SCALING_GROUP_NAME
    autoscaling = boto3.client('autoscaling', region_name='us-east-1')

    try:
        response = autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
        if response['AutoScalingGroups']:
            print(f"Auto Scaling Group '{asg_name}' already exists. Using the existing ASG.")
        else:
            print(f"Auto Scaling Group '{asg_name}' does not exist. Creating a new ASG.")
            create_auto_scaling_group(lt_id, tg_arn, region_name='us-east-1')
    except botocore.exceptions.ClientError as e:
        print(f"Error checking Auto Scaling Group: {e}")
        create_auto_scaling_group(lt_id, tg_arn, region_name='us-east-1')

    print_section('8. Create policy and attached to ASG')
    # TODO Create Simple Scaling Policies for ASG
    scale_out_policy_arn = create_scaling_policy(asg_name, 'scale-out-policy', 'ChangeInCapacity', SCALE_OUT_ADJUSTMENT, scale_in=False)
    scale_in_policy_arn = create_scaling_policy(asg_name, 'scale-in-policy', 'ChangeInCapacity', SCALE_IN_ADJUSTMENT, scale_in=True)
    print("Scaling policies created")
##check create_scaling_policy function

    print_section('9. Create Cloud Watch alarm. Action is to invoke policy.')
    # TODO create CloudWatch Alarms and link Alarms to scaling policies
    dimensions = [{'Name': 'AutoScalingGroupName', 'Value': asg_name}]
    create_cloudwatch_alarm( #change this
        alarm_name='scale-out-alarm',
        metric_name='CPUUtilization',
        namespace='AWS/EC2',
        statistic='Average',
        period=ALARM_PERIOD,
        evaluation_periods=ALARM_EVALUATION_PERIODS_SCALE_OUT,
        threshold=CPU_UPPER_THRESHOLD,
        comparison_operator='GreaterThanThreshold',
        alarm_actions=[scale_out_policy_arn],
        dimensions=dimensions,
        region_name='us-east-1'
    )
    create_cloudwatch_alarm(
        alarm_name='scale-in-alarm',
        metric_name='CPUUtilization',
        namespace='AWS/EC2',
        statistic='Average',
        period=60,
        evaluation_periods=ALARM_EVALUATION_PERIODS_SCALE_IN,
        threshold=CPU_LOWER_THRESHOLD,
        comparison_operator='LessThanThreshold',
        alarm_actions=[scale_in_policy_arn],
        dimensions=dimensions,
        region_name='us-east-1'
    )
    print("CloudWatch alarms created")


    # print_section('10. Submit ELB DNS to LG, starting warm up test.')
    # warmup_log_name = initialize_warmup(lg_dns, lb_dns)
    # while not is_test_complete(lg_dns, warmup_log_name):
    #     time.sleep(1)

    print_section('11. Submit ELB DNS to LG, starting auto scaling test.')
    
    log_name = initialize_test(lg_dns, lb_dns)
    while not is_test_complete(lg_dns, log_name):
        time.sleep(1)

    print_section('12. Monitor metrics')
    monitor_metrics()

    print_section('13. Adjust policies as needed')
    adjust_policies(scale_out_policy_arn, scale_in_policy_arn)

    destroy_resources()
    print("Resources destroyed")


if __name__ == "__main__":
    main()